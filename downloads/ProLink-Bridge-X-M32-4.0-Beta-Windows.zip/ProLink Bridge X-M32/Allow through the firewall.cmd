@echo off
title ProLink Bridge - Windows Firewall
setlocal

rem  Opens the ports ProLink Bridge needs in the Windows Firewall. Run it ONCE, on
rem  the machine where the bridge does not work.
rem
rem  Why this exists: Windows asks once, on first start, whether to let the
rem  program onto the network. If that prompt was dismissed - or never appeared,
rem  which happens when the program is started from a network folder or when
rem  the firewall is held by company policy - then SuperRack cannot find the
rem  console (its search arrives on UDP 40123), the link is never made (it
rem  knocks on TCP 50002), and the console appears dead (its replies come back
rem  over UDP and are stopped in the same place).
rem
rem  From the outside this looks exactly like "the program does not work on
rem  this computer".
rem
rem  NOTE for whoever edits this file: keep it ASCII only, no accented letters
rem  and no chcp. With "chcp 65001" inside, cmd.exe loses its position in the
rem  file and starts executing fragments of the comments - seen live on
rem  2026-08-30.

net session >nul 2>&1
if errorlevel 1 goto notadmin

set "EXE="
for %%F in ("%~dp0ProLink Bridge*.exe") do set "EXE=%%~fF"
if not defined EXE goto noexe

echo.
echo   Removing any old rules...
netsh advfirewall firewall delete rule name="Bridge M32" >nul 2>&1
netsh advfirewall firewall delete rule name="X-M32 Bridge" >nul 2>&1
netsh advfirewall firewall delete rule name="ProLink Bridge" >nul 2>&1

echo   Adding rules for:
echo     %EXE%
echo.

rem  The rule is on the PROGRAM, not on port numbers. That way it keeps working
rem  if the public port ever changes, and nothing else on the machine is opened.
netsh advfirewall firewall add rule name="ProLink Bridge" dir=in action=allow program="%EXE%" enable=yes profile=any
if errorlevel 1 goto bad

netsh advfirewall firewall add rule name="ProLink Bridge" dir=out action=allow program="%EXE%" enable=yes profile=any
if errorlevel 1 goto bad

echo.
echo   Done. Start the ProLink Bridge program; the panel opens by itself.
echo.
echo.
pause
exit /b 0

:notadmin
echo.
echo   This must be run AS ADMINISTRATOR.
echo.
echo   Close this window, right-click the file
echo   and choose "Run as administrator".
echo.
pause
exit /b 1

:noexe
echo.
echo   Cannot find the ProLink Bridge .exe next to this file.
echo   Put them in the same folder and try again.
echo.
pause
exit /b 1

:bad
echo.
echo   It did not work. Most often that means the firewall is held by
echo   company policy and cannot be changed from here.
echo.
pause
exit /b 1
